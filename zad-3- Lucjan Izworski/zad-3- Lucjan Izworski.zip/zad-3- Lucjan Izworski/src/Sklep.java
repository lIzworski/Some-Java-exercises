import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sklep {

    List<Towar> listaTowar = new ArrayList<>();
    List<Klient> listaKlient = new ArrayList<>();
    List<Transakcja> listaTransakcja = new ArrayList<>();

    public List<Towar> getListaTowar() {
        return listaTowar;
    }

    public List<Klient> getListaKlient() {
        return listaKlient;
    }

    public List<Transakcja> getListaTransakcja() {
        return listaTransakcja;
    }

    public void DodajTowar(Towar towar, int ilosc){
        if(listaTowar.contains(towar)){

            towar.setIlosc(towar.getIlosc()+ilosc);
        }
        else{
            listaTowar.add(towar);
        }
    }

    public void DodajKlienta(Klient klient){
        listaKlient.add(klient);
    }

    public void DodajTransakcje(Transakcja transakcje) throws Exception {



        //Sprawdz czy produkt jest dostępnyw liscie towarów
        if(listaTowar.contains(transakcje.getTowar())){
            int indexTowaru = listaTowar.indexOf(transakcje.getTowar());
            // Sprawdz czy mamy odpowiednią ilośc  tego produktu
            if(listaTowar.get(indexTowaru).getIlosc() >= transakcje.getIlosc()  ){
                //Dodaj transakcje
                listaTransakcja.add(transakcje);
                Towar towar = listaTowar.get(indexTowaru);
                towar.setIlosc(towar.getIlosc()-transakcje.getIlosc());
            }
            else{
                throw new Exception("Nie można dodać transakcji, ponieważ nie wystarczającej ilości produków");
            }
        }
        else{
            throw new Exception("Nie można dodać transakcji");
        }
    }
    public void PosortujListyTowarowPoNazwie(){

    }
}
