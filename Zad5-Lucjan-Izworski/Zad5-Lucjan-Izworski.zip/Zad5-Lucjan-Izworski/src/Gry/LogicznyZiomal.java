package Gry;

import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class LogicznyZiomal extends Gra{



    private int[][]tablica2d= new int [15][15];
    private int x = 8;
    private int y = 8;
    private int WygenerowanaLiczba;


    public int getWygenerowanaLiczba() {
        return WygenerowanaLiczba;
    }

    public void setWygenerowanaLiczba(int wygenerowanaLiczba) {
        WygenerowanaLiczba = wygenerowanaLiczba;
    }

    public void TablicaWielowymiarowa(){
        for(int i =1; i< tablica2d.length; i++){
            for (int j =1; j< tablica2d[i].length; j++){
                tablica2d[i][j] = i * j;
            }
        }
    }
    public void WyswietlTablice(){

        for (int i=1; i<=15; i++)
        {
            for (int j=1; j<=15; j++)
            {
                int a = i*j;
                System.out.printf("%4d", a);
            }
            System.out.println();
        }
    }
    public void TwojaPozycja(){

        System.out.println("Stoisz na liczbie : "+tablica2d[x][y] +" ( "+ x+" * "+y+" )");
    }
    public void Wygrywasz(){

    }
    @Override
    public void AkcjaW() {
        y=y-1;
        TwojaPozycja();
        IloscRuchow();
        //PokazSterowanie();
    }

    @Override
    public void AkcjaS() {
        y=y+1;
        TwojaPozycja();
        IloscRuchow();
        //PokazSterowanie();
    }

    @Override
    public void AkcjaA() {
        x=x-1;
        TwojaPozycja();
        IloscRuchow();
        //PokazSterowanie();
    }

    @Override
    public void AkcjaD() {
        x=x+1;
        TwojaPozycja();
        IloscRuchow();
        //PokazSterowanie();
    }

    @Override
    public String PodajTytul() {
        return "Logiczny Ziomal";
    }

    @Override
    public String PodajInstrukcje() {
        WyswietlWygenerowanąLiczbeIjąoddajDoSwitcha();
        Scanner scan = new Scanner(System.in);
        String instrukcja = scan.nextLine();
        return instrukcja;
    }
    public String MenuWybor(){
        Scanner scan = new Scanner(System.in);
        String instrukcja = scan.nextLine();
        return instrukcja;
    }
    public void CoDalej(){
        System.out.println("\nZakończyłeś, gre co chcesz robić dalej ?");
        System.out.println("1 - Zakończ gre i wróć do głownego menu wyboru gier");
        System.out.println("2 - Zagraj jeszcze raz");
        switch (MenuWybor()){
            case "1":
                Start s2 = new Start();
                s2.WybierzGre();
                break;
            case "2":
                Graj();
                break;
        }
    }
    @Override
    public void Pozegnaj() {
        System.out.println("Niestety nie udało ci się dostać do granicy tabeli liczb.");
        if(getIloscRuchow() == 1){
            System.out.println("Poległeś po "+getIloscRuchow()+ " ruchu");
        }
        else{
            System.out.println("Poległeś po "+getIloscRuchow()+ " ruchach");
        }
        EXIT = false;
        CoDalej();
    }
    public void PozaZakresemTablicy(){
        try {
            x = 16;
        }catch (ArrayIndexOutOfBoundsException e){
            Zwyciestwo();
        }
    }
    public void Zwyciestwo(){
        System.out.println("Brawo\nUdało ci sie przekroczyć granice tabeli.");
    }
    public void GeneratorLiczbLosowych(){
        Random generator = new Random();
        setWygenerowanaLiczba(generator.nextInt(4));
    }
    public void WyswietlWygenerowanąLiczbeIjąoddajDoSwitcha(){
        GeneratorLiczbLosowych();
        if(getWygenerowanaLiczba()==0){
            System.out.println("kolejna liczba musi być podzielna 2");
        }
        if(getWygenerowanaLiczba()==1){
            System.out.println("kolejna liczba musi być podzielna 3");
        }
        if(getWygenerowanaLiczba()==2){
            System.out.println("kolejna liczba musi być podzielna 2 lub 4");
        }
        if(getWygenerowanaLiczba()==3){
            System.out.println("kolejna liczba musi być podzielna 3 lub 6");
        }
    }

    public void PodzielnePrzez2(){
        if(((x*y)%2)==0){}
        else{
            Pozegnaj();
            EXIT = false;
        }
    }
    public void PodzielnePrzez3(){
        if(((x*y)%3)==0){}
        else{
            Pozegnaj();
            EXIT = false;
        }
    }
    public void PodzielnePrzez2i4(){
        if((((x*y)%2)|((x*y)%4) )==0){}
        else{
            Pozegnaj();
            EXIT = false;
        }
    }
    public void PodzielnePrzez3i6(){
        if((((x*y)%3)|((x*y)%6) )==0){}
        else{
            Pozegnaj();
            EXIT = false;
        }
    }




    @Override
    public void Zasady() {

        switch (getWygenerowanaLiczba()){
            case 0 -> PodzielnePrzez2();

            case 1 -> PodzielnePrzez3();

            case 2 -> PodzielnePrzez2i4();

            case 3 -> PodzielnePrzez3i6();
        }
    }

    @Override
    public void PoruszanieSie() {
        switch (PodajInstrukcje()) {
            case "w" -> AkcjaW();
            case "s" -> AkcjaS();
            case "a" -> AkcjaA();
            case "d" -> AkcjaD();
            case "x" -> Pozegnaj();
            case "W" -> AkcjaW();
            case "S" -> AkcjaS();
            case "A" -> AkcjaA();
            case "D" -> AkcjaD();
            case "X" -> Pozegnaj();
            default -> System.out.println("");
        }
    }
    @Override
    public void Cel() {
        System.out.println("\nZnajdujesz się na pozycji 8 x 8. Utknołeś w wymiarze liczb, aby się wydostać podążaj");
        System.out.println("za wskazówkami. Twoim celem jest wydostać się poza granice tabeli.\n");
        TablicaWielowymiarowa();
        WyswietlTablice();
        System.out.println("");
        TwojaPozycja();

    }

    @Override
    public int IloscRuchow() {
        setIloscRuchow(getIloscRuchow()+1);
        return 0;
    }

    @Override
    public void Resetuj() {
        EXIT =true;
        x = 8;
        y = 8;
        setIloscRuchow(0);
    }
}
