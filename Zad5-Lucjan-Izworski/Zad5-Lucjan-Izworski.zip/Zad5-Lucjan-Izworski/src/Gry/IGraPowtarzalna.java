package Gry;

public interface IGraPowtarzalna {
    public void PoinformujOPorazce();

}
