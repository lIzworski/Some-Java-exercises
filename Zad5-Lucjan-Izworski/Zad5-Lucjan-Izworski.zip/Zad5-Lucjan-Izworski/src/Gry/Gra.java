package Gry;

public abstract class Gra {
    //Pola klasy
    private String Tytul;
    private int iloscRuchow = 0;
    private int x = 0;
    private int y = 0;
    protected boolean EXIT = true;
    // Konstruktory
    public Gra(){
        this.Tytul = PodajTytul();
    }
    // Getery
    public int getIloscRuchow() {
        return iloscRuchow;
    }

    public String getTytul() {
        return Tytul;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    //Settery

    public void setIloscRuchow(int iloscRuchow) {
        this.iloscRuchow = iloscRuchow;
    }

    public int setX(int x) {
        this.x = x;
        return x;
    }

    public void setY(int y) {
        this.y = y;
    }

    //Metody abstrakcyjne
    public abstract  void AkcjaS();
    public abstract  void AkcjaW();
    public abstract  void AkcjaA();
    public abstract  void AkcjaD();
    public abstract String PodajTytul();
    public abstract String PodajInstrukcje();
    public abstract void Pozegnaj();
    public abstract void Zasady();
    public abstract void PoruszanieSie();
    public  void PokazSterowanie(){
        System.out.println("W grze sterujesz klawiszami  ( W metodach sterowania ta opcja została zakomentowana by nie wyświetlała się za każdym razem )  \n");
        System.out.println("         ^W   ");
        System.out.println("         |     ");
        System.out.println(" <-A           D->  ");
        System.out.println("         |     ");
        System.out.println("         vS   \n");
    };
    public abstract void Cel();
    public abstract int IloscRuchow();
    public abstract void Resetuj();
    //Metody
    public void Graj(){
        Resetuj();
        System.out.println(getTytul());
        System.out.println("");
        PokazSterowanie();
        Cel();
        while(EXIT==true){
            PoruszanieSie();
            Zasady();
        }
    }
}

