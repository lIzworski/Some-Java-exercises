package Gry;

import java.util.Scanner;

public class Start {
    public String wybor(){
        Scanner scan = new Scanner(System.in);
        String wybor = scan.next();
        return wybor;
    }
    public void WybierzGre(){
        System.out.println("A - Matematyczny Bieg");
        System.out.println("B - Logiczny Ziomal");
        switch (wybor()){
            case "A" -> MatematycznyBieg();
            case "B" -> LogicznyZiomal();
            case "a" -> MatematycznyBieg();
            case "b" -> LogicznyZiomal();
        }
    }
    private void MatematycznyBieg(){
        MatematycznyBieg m1 = new MatematycznyBieg();
        m1.Graj();
    }
    private void LogicznyZiomal(){
        LogicznyZiomal l1 = new LogicznyZiomal();
        l1.Graj();
    }
    public static void main(String []args){


        System.out.println("Witaj w menu wyboru gier\n");
        Start s1 = new Start();
        s1.WybierzGre();

    }
}
